// SG90 servo controlled from a browser slider (Web Serial) on Arduino Uno R3
// Wiring: Servo orange/yellow -> D9 | red -> 5V | brown/black -> GND

#include <Servo.h>

const uint8_t SERVO_PIN = 9;
Servo servo;

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(20);
  servo.attach(SERVO_PIN, 500, 2400);  // SG90 pulse range in microseconds
  servo.write(90);                      // start at centre
}

void loop() {
  if (Serial.available()) {
    // Expects a line like "135\n"
    int angle = Serial.parseInt();
    angle = constrain(angle, 0, 180);
    servo.write(angle);
    Serial.print("OK ");
    Serial.println(angle);
    while (Serial.available()) Serial.read();  // flush leftover newline
  }
}
